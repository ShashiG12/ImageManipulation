package view;

/**
 * Enum denoting the file type supported by our program. More types could be added in the future.
 */
public enum FileType {
  PPM,
  POPULAR;
}
